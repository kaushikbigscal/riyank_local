# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_access_rights
from . import test_attendees
from . import test_calendar
from . import test_calendar_controller
from . import test_calendar_recurrent_event_case2
from . import test_event_recurrence
from . import test_event_notifications
from . import test_mail_activity_mixin
from . import test_res_partner
from . import test_recurrence_rule

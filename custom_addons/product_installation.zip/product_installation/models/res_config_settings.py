from odoo import fields, models,api

class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    enable_distributor = fields.Boolean(
        string="Distributor Feature",
        config_parameter='product_installation.enable_distributor'
    )

    @api.model
    def _register_hook(self):
        """Set initial menu visibility when module is installed/updated"""
        res = super()._register_hook()
        self._update_menu_visibility()
        return res

    @api.model
    def _update_menu_visibility(self):
        param_value = self.env['ir.config_parameter'].sudo().get_param(
            'product_installation.enable_distributor', 'False'
        )
        enabled = (param_value == 'True')
        menu_xml_ids = [
            'product_installation.menu_product_stock_distributor',
            'product_installation.menu_distribution_management',
        ]

        for xml_id in menu_xml_ids:
            menu = self.env.ref(xml_id, raise_if_not_found=False)
            if menu:
                menu.sudo().active = enabled

    def set_values(self):
        res = super().set_values()
        # after saving settings update menu
        self._update_menu_visibility()
        return res
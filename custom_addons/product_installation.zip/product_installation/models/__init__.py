from . import product
from . import sale_order
from . import res_config_settings
from . import res_partenr
from . import distributor_asset
from . import customer_product_mapping
from . import stock_picking



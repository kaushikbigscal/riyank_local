# -*- coding: utf-8 -*-

from . import monthly_attendance_report
from . import attendance_correction
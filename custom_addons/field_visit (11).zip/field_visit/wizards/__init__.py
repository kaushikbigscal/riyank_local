# Copyright 2021 Sygel - Valentin Vinagre
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html)

from . import field_visit_close_wiz
from . import field_visit_template_create
from . import field_visit_justify_wizard

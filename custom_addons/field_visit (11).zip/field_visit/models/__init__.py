
from . import field_visit
# from . import field_visit_dashboard
from . import field_visit_template
from . import field_visit_close_reason
from . import res_partner
from . import res_company
# from . import crm_lead
from . import calendar_event
from . import res_config_settings
from . import visit_objective_tags
# from . import state_city
from . import city_zip
from . import route
from . import route_assigment
from . import field_visit_timesheet
